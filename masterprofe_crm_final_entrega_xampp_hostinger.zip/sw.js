
const CACHE='master-profe-crm-v4';
const ASSETS=['assets/css/app.css','assets/js/app.js','assets/js/auth.js','assets/img/icon.svg','assets/img/avatar.svg','manifest.json'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).catch(()=>{}));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',e=>{
  const url=new URL(e.request.url);
  if(e.request.method!=='GET' || url.pathname.includes('/api/') || url.pathname.endsWith('.php')) return;
  e.respondWith(fetch(e.request).then(r=>{const clone=r.clone();caches.open(CACHE).then(c=>c.put(e.request,clone)).catch(()=>{});return r;}).catch(()=>caches.match(e.request)));
});
