document.getElementById('loginForm').addEventListener('submit', async e=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  try{
    const r=await fetch('api/login.php',{method:'POST',body:fd,credentials:'same-origin',redirect:'follow'});
    const j=await r.json();
    if(j.ok){
      const local = ['localhost','127.0.0.1'].includes(location.hostname);
      location.replace(local ? './index.php?view=dashboard' : './dashboard');
      return;
    }
    Swal.fire('Error',j.message||'Credenciales inválidas','error');
  }catch(err){
    Swal.fire('Error','No se pudo conectar con el servidor. Verificá Apache/PHP y la conexión a la base de datos.','error');
  }
});
const $=s=>document.querySelector(s);
$('#createBtn')?.addEventListener('click',async()=>{
  const {value:form}=await Swal.fire({title:'Crear cuenta de socio',html:`<form id="regForm" class="form-grid"><div class="field full"><label>Nombre completo</label><input name="full_name" required></div><div class="field full"><label>Email</label><input name="email" type="email" required></div><div class="field full"><label>Contraseña</label><input name="password" type="password" minlength="6" required></div></form>`,showCancelButton:true,confirmButtonText:'Enviar solicitud',preConfirm:()=>{const f=$('#regForm'); const fd=new FormData(f); return fetch('api/register.php',{method:'POST',body:fd}).then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.message); return j}).catch(e=>Swal.showValidationMessage(e.message));}});
  if(form) Swal.fire('Solicitud enviada',form.message||'Cuenta creada pendiente de aprobación.','success');
});
$('#recoverBtn')?.addEventListener('click',async()=>{
  const {value:email}=await Swal.fire({title:'Recuperar contraseña',input:'email',inputLabel:'Email de tu cuenta',showCancelButton:true,confirmButtonText:'Solicitar recupero'});
  if(!email)return; const fd=new FormData(); fd.append('email',email); const j=await fetch('api/recover.php',{method:'POST',body:fd}).then(r=>r.json()).catch(()=>({ok:false,message:'Error de conexión'})); Swal.fire(j.ok?'Solicitud recibida':'Error',j.message,j.ok?'success':'error');
});
$('#googleBtn')?.addEventListener('click',()=>Swal.fire('Google OAuth','La interfaz ya está preparada. Para activarlo se deben configurar las credenciales OAuth de Google en Hostinger y crear el endpoint de callback autorizado.','info'));
if('serviceWorker' in navigator && !['localhost','127.0.0.1'].includes(location.hostname)) navigator.serviceWorker.register('./sw.js').catch(()=>{});
