document.getElementById('loginForm').addEventListener('submit', async e=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  try{
    const r=await fetch('api/login.php',{method:'POST',body:fd,credentials:'same-origin'});
    const j=await r.json();
    if(j.ok){
      const local = ['localhost','127.0.0.1'].includes(location.hostname);
      location.href = local ? 'index.php#dashboard' : 'dashboard';
      return;
    }
    Swal.fire('Error',j.message||'Credenciales inválidas','error');
  }catch(err){
    Swal.fire('Error','No se pudo conectar con el servidor. Verificá PHP/MySQL y la ruta del proyecto.','error');
  }
});
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
