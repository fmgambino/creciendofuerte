EL MASTER PROFE CRM - instalación

1) Local XAMPP
- Copiar la carpeta del proyecto dentro de htdocs.
- Crear/importar la base local con: sql/FULL_REINSTALL_LOCAL_XAMPP.sql
- Abrir: http://localhost/<carpeta>/login.php
- Usuario demo: fernando.m.gambino@gmail.com
- Contraseña: Demo1234

2) Hostinger
- Subir todos los archivos al public_html de creciendofuerte.com.
- Importar dentro de la base u570224512_master10k el archivo:
  sql/FULL_REINSTALL_HOSTINGER.sql
- Editar config/database.php y cambiar DB_PASS por la contraseña real del usuario MySQL.
- Abrir: https://creciendofuerte.com/login

3) Patch seguro de permisos
- Si NO querés borrar datos, importar solo:
  sql/PATCH_PERMISOS_HOSTINGER_SEGURO.sql

Notas
- La app soporta URLs limpias con .htaccess: /login, /dashboard, /perfil, /roles, etc.
- En localhost se mantiene compatibilidad con index.php#dashboard para evitar problemas de rewrite.
- El dashboard tiene filtros Desde/Hasta, Socio, Referente y tipo de gráfico Línea/Barra/Torta.
