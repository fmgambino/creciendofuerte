const CACHE='master-profe-crm-v2-hostinger';
const ASSETS=['./','login.php','index.php','assets/css/app.css','assets/js/app.js','assets/js/auth.js','assets/img/icon.svg','assets/img/avatar.svg'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).catch(()=>{}));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',e=>{
  const url=new URL(e.request.url);
  if(e.request.method!=='GET' || url.pathname.includes('/api/')) return;
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});
