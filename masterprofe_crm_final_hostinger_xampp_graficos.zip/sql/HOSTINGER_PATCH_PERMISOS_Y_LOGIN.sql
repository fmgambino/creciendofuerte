-- HOSTINGER PATCH - EL MASTER PROFE CRM
-- Ejecutar dentro de la base seleccionada: u570224512_master10k
-- NO usa CREATE DATABASE ni USE para evitar errores de permisos en Hostinger.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS profile_photo VARCHAR(255) DEFAULT 'assets/img/avatar.svg',
  ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE permissions
  ADD COLUMN IF NOT EXISTS can_create TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS can_edit TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS can_delete TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS can_export TINYINT(1) NOT NULL DEFAULT 0;

-- Garantiza índice único requerido por ON DUPLICATE KEY UPDATE.
SET @idx := (SELECT COUNT(1) FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name='permissions' AND index_name='uk_perm');
SET @sql := IF(@idx=0, 'ALTER TABLE permissions ADD UNIQUE KEY uk_perm(module_key, role)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Contraseña demo Demo1234 para el superadmin indicado.
UPDATE users
SET password_hash = '$2y$12$NfLavdL2uvgiqPdr9i7Y8OIg.RuG/kws.OW4QnsaK51.QZVWda7re',
    status = 'active',
    role = 'superadmin'
WHERE email = 'fernando.m.gambino@gmail.com';

-- Permisos completos por módulo y rol.
INSERT INTO permissions(module_key,module_name,role,can_view,can_create,can_edit,can_delete,can_export)
SELECT m.k,m.n,r.role,
 CASE WHEN r.role='superadmin' THEN 1 WHEN r.role='empleado' AND m.k NOT IN('users','roles','whatsapp') THEN 1 WHEN r.role='socio' AND m.k IN('dashboard','perfil','referidos','distribuciones','retiros','notificaciones') THEN 1 ELSE 0 END,
 CASE WHEN r.role='superadmin' THEN 1 WHEN r.role='empleado' AND m.k IN('socios','referidos','profits','retiros','notificaciones') THEN 1 WHEN r.role='socio' AND m.k IN('referidos','retiros') THEN 1 ELSE 0 END,
 CASE WHEN r.role='superadmin' THEN 1 WHEN r.role='empleado' AND m.k IN('socios','referidos','profits','retiros','notificaciones') THEN 1 WHEN r.role='socio' AND m.k IN('perfil','referidos') THEN 1 ELSE 0 END,
 CASE WHEN r.role='superadmin' THEN 1 ELSE 0 END,
 CASE WHEN r.role='superadmin' THEN 1 WHEN r.role='empleado' AND m.k NOT IN('roles','whatsapp') THEN 1 WHEN r.role='socio' AND m.k IN('referidos','distribuciones','retiros') THEN 1 ELSE 0 END
FROM (SELECT 'dashboard' k,'Dashboard' n UNION SELECT 'perfil','Mi Perfil' UNION SELECT 'users','Usuarios' UNION SELECT 'roles','Roles y permisos' UNION SELECT 'socios','Socios' UNION SELECT 'referidos','Referidos' UNION SELECT 'profits','Ganancias broker' UNION SELECT 'distribuciones','Distribuciones' UNION SELECT 'retiros','Retiros' UNION SELECT 'whatsapp','WhatsApp' UNION SELECT 'notificaciones','Notificaciones' UNION SELECT 'auditoria','Auditoría') m
CROSS JOIN (SELECT 'superadmin' role UNION SELECT 'empleado' UNION SELECT 'socio') r
ON DUPLICATE KEY UPDATE
 module_name=VALUES(module_name),
 can_view=VALUES(can_view),
 can_create=VALUES(can_create),
 can_edit=VALUES(can_edit),
 can_delete=VALUES(can_delete),
 can_export=VALUES(can_export);
