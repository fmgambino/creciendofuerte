-- PATCH SEGURO PARA HOSTINGER / XAMPP
-- No usa ON DUPLICATE KEY UPDATE para evitar errores del parser de phpMyAdmin.
-- Ejecutar dentro de la base correspondiente:
--   Local: revenue_crm
--   Hostinger: u570224512_master10k

DELETE FROM permissions;

INSERT INTO permissions(module_key,module_name,role,can_view,can_create,can_edit,can_delete,can_export) VALUES
('dashboard','Dashboard','superadmin',1,1,1,1,1),
('dashboard','Dashboard','empleado',1,0,0,0,1),
('dashboard','Dashboard','socio',1,0,0,0,0),
('perfil','Mi Perfil','superadmin',1,1,1,1,1),
('perfil','Mi Perfil','empleado',1,0,0,0,1),
('perfil','Mi Perfil','socio',1,0,1,0,0),
('users','Usuarios','superadmin',1,1,1,1,1),
('users','Usuarios','empleado',0,0,0,0,1),
('users','Usuarios','socio',0,0,0,0,0),
('roles','Roles y permisos','superadmin',1,1,1,1,1),
('roles','Roles y permisos','empleado',0,0,0,0,0),
('roles','Roles y permisos','socio',0,0,0,0,0),
('socios','Socios','superadmin',1,1,1,1,1),
('socios','Socios','empleado',1,1,1,0,1),
('socios','Socios','socio',0,0,0,0,0),
('referidos','Referidos','superadmin',1,1,1,1,1),
('referidos','Referidos','empleado',1,1,1,0,1),
('referidos','Referidos','socio',1,1,1,0,1),
('profits','Ganancias broker','superadmin',1,1,1,1,1),
('profits','Ganancias broker','empleado',1,1,1,0,1),
('profits','Ganancias broker','socio',0,0,0,0,0),
('distribuciones','Distribuciones','superadmin',1,1,1,1,1),
('distribuciones','Distribuciones','empleado',1,0,0,0,1),
('distribuciones','Distribuciones','socio',1,0,0,0,1),
('retiros','Retiros','superadmin',1,1,1,1,1),
('retiros','Retiros','empleado',1,1,1,0,1),
('retiros','Retiros','socio',1,1,0,0,1),
('whatsapp','WhatsApp','superadmin',1,1,1,1,1),
('whatsapp','WhatsApp','empleado',0,0,0,0,0),
('whatsapp','WhatsApp','socio',0,0,0,0,0),
('notificaciones','Notificaciones','superadmin',1,1,1,1,1),
('notificaciones','Notificaciones','empleado',1,1,1,0,1),
('notificaciones','Notificaciones','socio',1,0,0,0,0),
('auditoria','Auditoría','superadmin',1,1,1,1,1),
('auditoria','Auditoría','empleado',1,0,0,0,1),
('auditoria','Auditoría','socio',0,0,0,0,0);

UPDATE users SET status='active' WHERE email='fernando.m.gambino@gmail.com';
